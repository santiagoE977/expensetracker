# models.py is optional since model is in app.py; kept for clarity if you want to refactor.
pass
