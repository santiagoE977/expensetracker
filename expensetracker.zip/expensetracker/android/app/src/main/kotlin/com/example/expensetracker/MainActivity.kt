package com.example.expensetracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
