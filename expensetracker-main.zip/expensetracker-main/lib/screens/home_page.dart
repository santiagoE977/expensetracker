import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/expense.dart';
import '../services/api_service.dart';
import 'add_expense_page.dart';

class HomePage extends StatefulWidget {
  final int userId; // ✅ obligatorio
  const HomePage({Key? key, required this.userId}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Expense> _expenses = [];
  bool _isLoading = true;
  final ApiService apiService = ApiService();

  Future<void> fetchExpenses() async {
    try {
      // ✅ pasa userId al cliente
      final data = await apiService.getExpenses(userId: widget.userId);
      final loadedExpenses = (data as List)
          .map((json) => Expense.fromJson(json as Map<String, dynamic>))
          .toList();

      setState(() {
        _expenses = loadedExpenses;
        _isLoading = false;
      });
    } catch (e) {
      debugPrint('Error al cargar gastos: $e');
      setState(() => _isLoading = false);
    }
  }

  @override
  void initState() {
    super.initState();
    fetchExpenses();
  }

  double get totalThisMonth {
    return _expenses.fold(0, (sum, item) => sum + item.monto);
  }

  Map<String, double> get categoryTotals {
    final data = <String, double>{};
    for (var exp in _expenses) {
      data[exp.categoria] = (data[exp.categoria] ?? 0) + exp.monto;
    }
    return data;
  }

  void _goToAddExpensePage() async {
    final added = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AddExpensePage(userId: widget.userId),
      ),
    );
    if (added == true) {
      await fetchExpenses();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Rastreador de gastos")),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Card(
                    elevation: 4,
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: Text(
                        "Este mes: \$${totalThisMonth.toStringAsFixed(2)}",
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: _goToAddExpensePage,
                    child: const Text("+ Agregar gasto"),
                  ),
                  const SizedBox(height: 20),
                  Expanded(
                    child: _expenses.isEmpty
                        ? const Center(
                            child: Text(
                              "Aún no tienes gastos registrados.",
                              style: TextStyle(fontSize: 18),
                            ),
                          )
                        : Card(
                            elevation: 3,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: BarChart(
                                BarChartData(
                                  alignment: BarChartAlignment.spaceAround,
                                  titlesData: FlTitlesData(
                                    bottomTitles: AxisTitles(
                                      sideTitles: SideTitles(
                                        showTitles: true,
                                        getTitlesWidget: (value, meta) {
                                          final categories = categoryTotals.keys
                                              .toList();
                                          if (value.toInt() <
                                              categories.length) {
                                            return Text(
                                              categories[value.toInt()],
                                              style: const TextStyle(
                                                fontSize: 10,
                                              ),
                                            );
                                          }
                                          return const Text("");
                                        },
                                      ),
                                    ),
                                    leftTitles: const AxisTitles(
                                      sideTitles: SideTitles(showTitles: true),
                                    ),
                                  ),
                                  borderData: FlBorderData(show: false),
                                  barGroups: categoryTotals.entries
                                      .toList()
                                      .asMap()
                                      .entries
                                      .map(
                                        (entry) => BarChartGroupData(
                                          x: entry.key,
                                          barRods: [
                                            BarChartRodData(
                                              toY: entry.value.value,
                                              color: Colors.blue,
                                              width: 18,
                                              borderRadius:
                                                  BorderRadius.circular(4),
                                            ),
                                          ],
                                        ),
                                      )
                                      .toList(),
                                ),
                              ),
                            ),
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}
