import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/expense.dart';

class ApiService {
  static const String baseUrl = 'http://127.0.0.1:5000';

  // GET /expenses?user_id=...&category=...
  Future<List<dynamic>> getExpenses({
    required int userId,
    String? category,
  }) async {
    final params = <String, String>{'user_id': '$userId'};
    if (category != null) params['category'] = category;
    final uri = Uri.parse('$baseUrl/expenses').replace(queryParameters: params);
    final response = await http.get(uri);
    if (response.statusCode == 200) return json.decode(response.body);
    throw Exception('Error al obtener gastos: ${response.statusCode}');
  }

  // POST /expenses con user_id
  static Future<void> addExpense(Expense expense, {required int userId}) async {
    final body = expense.toJson();
    body['user_id'] = userId;
    final response = await http.post(
      Uri.parse('$baseUrl/expenses'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode(body),
    );
    if (response.statusCode != 201) {
      throw Exception('Error al agregar gasto: ${response.body}');
    }
  }

  // DELETE /expenses/:id
  static Future<void> deleteExpense(int id) async {
    final response = await http.delete(Uri.parse('$baseUrl/expenses/$id'));
    if (response.statusCode != 200) {
      throw Exception('Error al eliminar gasto: ${response.statusCode}');
    }
  }

  // GET /categories?user_id=...
  static Future<List<String>> getCategories({required int userId}) async {
    final uri = Uri.parse(
      '$baseUrl/categories',
    ).replace(queryParameters: {'user_id': '$userId'});
    final response = await http.get(uri);
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      return data.cast<String>();
    } else {
      throw Exception('Error al obtener categorías: ${response.statusCode}');
    }
  }

  // PUT /expenses/:id
  static Future<void> updateExpense(
    int id,
    Map<String, dynamic> updatedData,
  ) async {
    final url = Uri.parse('$baseUrl/expenses/$id');
    final response = await http.put(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(updatedData),
    );
    if (response.statusCode != 200) {
      throw Exception('Error al actualizar el gasto: ${response.statusCode}');
    }
  }

  // POST /register
  static Future<Map<String, dynamic>?> register(
    String name,
    String email,
    String password,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl/register'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'name': name, 'email': email, 'password': password}),
    );
    if (response.statusCode == 201) return jsonDecode(response.body);
    return null;
  }

  // POST /login
  static Future<Map<String, dynamic>?> login(
    String email,
    String password,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'email': email, 'password': password}),
    );
    if (response.statusCode == 200) return jsonDecode(response.body);
    return null;
  }
}
